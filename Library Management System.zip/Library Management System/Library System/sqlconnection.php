<?php
	$sqlcon = mysqli_connect("localhost", "root", "", "library");
?>
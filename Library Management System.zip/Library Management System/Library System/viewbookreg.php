<?php
	session_start();
	require('./filecall.php'); 
	require "sqlconnection.php";
	if (!isset($_COOKIE['UserCookie'])){
		header('Location: index.php');
		exit;
	}
	if ($_COOKIE['UserType']=="Admin"){
		header('Location: adminform.php');
		exit;
	}
?>

<?php 
    function generaterecord(){
        include 'sqlconnection.php';
        $sqlstring="select * FROM bookdb1 ORDER BY Bookname DESC";
        echo "<form name='update' method='GET'>";
        $resultset=mysqli_query($sqlcon, $sqlstring);


        while($rowdata = mysqli_fetch_array($resultset))  
            {  
                echo "<tr>"; 
                    echo "<td>$rowdata[0]</td>";
					echo "<td><a href='book.php?bookID=$rowdata[0]'>$rowdata[1]</a></td>";
					echo "<td>$rowdata[2]</td>";
                    echo "<td>$rowdata[3]</td>";
                    echo "<td>$rowdata[4]</td>";
                    echo "<td>$rowdata[5]</td>";
                    echo '<td><button style="font-size: 0.8em; width: 15vh;" type="button" class="openupModal btn btn-success" data-toggle="modal" data-target="#updateModal">Reserve</button>&nbsp';
                    echo '</td>';
				    echo "</tr>";
            }  
        mysqli_close($sqlcon);
        
    }	
?>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
</head>

<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigationuser.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">View / Account Logs</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, Jamille C. Legaspi!</p>
            </div>

            <div class="col-12 p-2" id="midMain">
                
                <div class="col-12 overflow-auto" style="height: 79vh; background-color: #f2f2f2;">
                    <div class="p-3">  
                        <table id="ShowTable" class="table table-striped table-bordered">  
                                <thead class="table-dark" style="position: sticky; top: 0; z-index: 1;">
                                <tr>  
                                        <td id="row1vb">BookID</td>  
                                        <td id="row2vb">BookName</td>  
                                        <td id="row3vb">Author</td>  
                                        <td id="row4vb">Genre</td>  
                                        <td id="row5vb">ISBN</td>  
                                        <td id="row6vb">Status</td>
                                        <td id="row7vb">Reserve</td>  
                                </tr>  
                            </thead> 
                            <tbody> 
                                <?php
                                    echo generaterecord();
                                ?>
                            </tbody> 
                        </table>  
                    </div>
                </div>
                 
        </div>
    </div>
</div>   
</body>

<!-- Modal Accept-->
<div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="productname1"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="border:0; background: 000;">
        <span aria-hidden="true"><i class="fa-sharp fa-solid fa-xmark"></i></span>
        </button>
      </div>
      <div class="modal-body">
            Are you sure you want to reserve this book?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a id="accept"><button class="btn btn-danger">Okey</button></a>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
    

    $("#ShowTable").on('click','.openupModal',function () {
        var currentRow=$(this).closest("tr");
        var id = currentRow.find("td:eq(0)").text();
        var bookname = currentRow.find("td:eq(1)").text();
        document.getElementById("productname1").innerHTML = bookname;
        document.getElementById("accept").href = "reservedbooks.php?bookname="+bookname+" & bookid="+id+" ";
        
    });
</script>
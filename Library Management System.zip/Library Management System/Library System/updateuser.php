<?php
    include "sqlconnection.php";
    $id= mysqli_real_escape_string($sqlcon, $_GET['id']);
    $un= mysqli_real_escape_string($sqlcon, $_GET['un']);
    $pass= mysqli_real_escape_string($sqlcon,$_GET['pass']);
    $name= mysqli_real_escape_string($sqlcon, $_GET['name']);
    if($id=='' or $un=='' or $pass=='' or $name==''){
        echo '<script>alert("Field Cannot be Empty!")</script>';
        return false;
    }
    else{
    $sqlstring="update userbase SET userID=$id, username='$un', password='$pass', name='$name' WHERE userID=$id";
    mysqli_query($sqlcon, $sqlstring);//DB, sql command
    mysqli_close($sqlcon);
    echo '<script>alert("Record Updated!")</script>';
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='viewusers.php';
    </script>");
    }
?>
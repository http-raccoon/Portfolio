<?php
    include "sqlconnection.php";
    $bid= mysqli_real_escape_string($sqlcon, $_GET['id']);
    $bookn= mysqli_real_escape_string($sqlcon, $_GET['name']);
    $author= mysqli_real_escape_string($sqlcon,$_GET['author']);
    $genre= mysqli_real_escape_string($sqlcon, $_GET['genre']);
    if($bid=='' or $bookn=='' or $author=='' or $genre==''){
        echo '<script>alert("Field Cannot be Empty!")</script>';
        return false;
    }
    else{
    $sqlstring="update bookdb1 SET bookID=$bid, Bookname='$bookn', Author='$author', genre='$genre' WHERE bookID=$bid";
    mysqli_query($sqlcon, $sqlstring);//DB, sql command
    mysqli_close($sqlcon);
    echo '<script>alert("Record Updated!")</script>';
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='viewbook.php';
    </script>");
    }	
?>
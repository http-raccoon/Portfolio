<?php
	session_start();
    require('./filecall.php'); 
	require "sqlconnection.php";
	
    if (!isset($_COOKIE['UserCookie'])){
		header('Location: index.php');
		exit;
	}
	if ($_COOKIE['UserType']=="Regular"){
		header('Location: regularform.php');
		exit;
	}
    
?>

<?php 
    function generaterecord(){
        include 'sqlconnection.php';
        $sqlstring="select * FROM bookdb1 ORDER BY Bookname DESC";
        echo "<form name='update' method='GET'>";
        $resultset=mysqli_query($sqlcon, $sqlstring);


        while($rowdata = mysqli_fetch_array($resultset))  
            {  
                echo "<tr>"; 
                    echo "<td>$rowdata[0]</td>";
					          echo "<td><a href='book.php?bookID=$rowdata[0]'>$rowdata[1]</a></td>";
					          echo "<td>$rowdata[2]</td>";
                    echo "<td>$rowdata[3]</td>";
                    echo "<td>$rowdata[4]</td>";
                    echo "<td>$rowdata[5]</td>";
                    echo '<td><button style="font-size: 0.8em; width: 8vh;" type="button" class="openupModal btn btn-warning" data-toggle="modal" data-target="#updateModal">Update</button>&nbsp';
                    echo '<button style="font-size: 0.8em; width: 8vh;" type="button" class="opendelModal btn btn-Danger" data-toggle="modal" data-target="#deleteModal">Delete</button></td>';
				        echo "</tr>";
            }  
        mysqli_close($sqlcon);
        
    }	
?>



<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
	<script>
	function printtest(){
		var divToPrint=document.getElementById("ShowTable");
		newWin= window.open("");
		newWin.document.write(divToPrint.outerHTML);
		newWin.print();
		newWin.close();
	}
	</script>
</head>

<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigation.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">View / Books</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, <?php echo $_COOKIE['UserCookie']; ?>!</p>
            </div>
            
            <div class="col-12 p-2" id="midMain">
                
                <div class="col-12 overflow-auto" style="height: 79vh; background-color: #f2f2f2;">
                    <div class="p-3">  
                        <table id="ShowTable" class="table table-striped table-bordered">  
                                <thead class="table-dark" style="position: sticky; top: 0; z-index: 1;">
                                <tr>  
                                        <td id="row1vb">BookID</td>  
                                        <td id="row2vb">BookName</td>  
                                        <td id="row3vb">Author</td>  
                                        <td id="row4vb">Genre</td>  
                                        <td id="row5vb">ISBN</td>  
                                        <td id="row6vb">Status</td>
                                        <td id="row7vb">Edit record</td>  
                                </tr>  
                            </thead> 
                            <tbody> 
                                <?php
                                    echo generaterecord();
                                ?>
                            </tbody> 
                        </table>  
                    </div>
                </div> 
                
                <div class="d-flex flex-column-reverse">
                    <div class="align-self-end">
                        <button class="btn btn-primary" style="vertical-align:middle; margin-top:10px; margin-right:30px; width: 30vh;" onclick="printtest()">Print table page</button><button onclick="addbook()" style="vertical-align:middle; margin-top:10px; margin-right:30px; width: 30vh;" class="btn btn-Primary">Add Book</button>
                    </div>
                </div>
                
            </div>     
        </div>
    </div>
</div>   

</body>

<!-- Modal Delete-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="productname"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="border:0; background: 000;">
        <span aria-hidden="true"><i class="fa-sharp fa-solid fa-xmark"></i></span>
        </button>
      </div>
      <div class="modal-body">
            Are you sure you want to delete this item?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a id="delete"><button class="btn btn-danger">Delete Product</button></a>
      </div>
    </div>
  </div>
</div>




<!-- Modal Update-->
<div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="productname">Update Book</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="border:0; background: 000;">
          <span aria-hidden="true"><i class="fa-sharp fa-solid fa-xmark"></i></span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-group">
            <label for="book-id" class="col-form-label">Book ID:</label>
            <input type="text" class="form-control" id="book-id" name="book-id" readonly required>
          </div>
          <div class="form-group">
            <label for="book-name" class="col-form-label">Book Name:</label>
            <input type="text" class="form-control" id="book-name" name="book-name" required>
          </div>
          <div class="form-group">
            <label for="author-name" class="col-form-label">Author:</label>
            <input type="text" class="form-control" id="author-name" name="author-name" required>
          </div>
          <div class="form-group">
            <label for="genre-name" class="col-form-label">Genre:</label>
            <input type="text" class="form-control" id="genre-name" name="genre-name" required>
          </div>
      </div>
      <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button onclick="submit()" class="btn btn-warning">Update Book</button>
      </div>
    </div>
  </div>
</div>




<!-- for modal -->
<script type="text/javascript">
    $("#ShowTable").on('click','.opendelModal',function () {
        var currentRow=$(this).closest("tr");
        var id = currentRow.find("td:eq(0)").text();
        var name = currentRow.find("td:eq(1)").text();
        document.getElementById("productname").innerHTML = name;
        document.getElementById("delete").href = "deletebook.php?id=".concat(id);
    });

    $("#ShowTable").on('click','.openupModal',function () {
        var currentRow=$(this).closest("tr");
        var id = currentRow.find("td:eq(0)").text();
        var name = currentRow.find("td:eq(1)").text();
        var author = currentRow.find("td:eq(2)").text();
        var genre = currentRow.find("td:eq(3)").text();
        document.getElementById("book-id").value = id;
        document.getElementById("book-name").value = name;
        document.getElementById("author-name").value = author;
        document.getElementById("genre-name").value = genre;
    });

    
    function submit(){
      var id1 = document.getElementById("book-id").value;
      var name1 = document.getElementById("book-name").value;
      var author1 = document.getElementById("author-name").value;
      var genre1 =document.getElementById("genre-name").value;
      var pathh = "updatebook.php?id="+id1+" & name="+name1+" & author="+author1+" & genre="+genre1+" ";
      window.location.href = pathh;
    }

    function submit1(){
      var isbn = document.getElementById("isbn").value;
      var bname = document.getElementById("bname").value;
      var author = document.getElementById("author").value;
      var category = document.getElementById("category").value;
      var publisher =document.getElementById("publisher").value;
      var published = document.getElementById("published").value;
      var pages = document.getElementById("pagec").value;
      var description = document.getElementById("description").value;
      var pathh = "addbook.php?isbn="+isbn+" & bname="+bname+" & author="+author+" & category="+category+" & publisher="+publisher+" & published="+published+" & pages="+pages+" & description="+description+" ";
      window.location.href = pathh;
    }

    function addbook(){
      var pathh = "searchbook.php";
      window.location.href = pathh;
    }


</script>
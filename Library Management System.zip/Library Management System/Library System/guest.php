<?php
	session_start();
    require('./filecall.php'); 
	require "sqlconnection.php";
?>

<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
	
</head>

<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigationguest.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">FAQs/Help</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, <?php echo $_COOKIE['UserCookie']; ?>!</p>
            </div>
			
			<div class="col-12" id="midMain">
	
			
			<div class="col-md-12 col-sm-12">
                    <div style="background-color:#f2f2f2;">
                        <div style="height:5vh; width:100%; background-color: #373b3e; color:fff;">
                            <p style="font-size:3.5vh; padding-left:650px;">Help Desk</p>
                        </div>
				<div style="padding-left:100px;">
					<div>
						<h2>How to Register</h2>
					</div>
					<div>
						<ol>You may register inside the Malabon Library. Please ask for assistance.
						
						<li>1. To register in the library, please approach the librarian and provide your valid ID. 
						<li>2. Upon confirmation, you shall receive an email from the library as notification.
						</ol>
				<div>	<h3>Website</h3>
						<ol>Guidelines
						<li>1. Users may browse the list of books within the library, and view their availability.
						<li>2. They may also reserve a book to be picked up within the day. Upon failure to do so, the request
						<li>shall be rejected. 
						<li>3. Users may view their record history, and pending requests. 
						<ol>
				</div>
				<div><h3>Facility</h3>
					Rules and Regulations
					<ol>Library Hours
						<li>Monday to Friday: 8:00am - 12:00pm, 1:00pm-6:00pm
					</ol>
					
					<h3>Rules on Conduct for the facility</h3>
					<ol>
						<li>1. Silence must be observed in the library.
						<li>2. Readers are not aloud to talk loudly or eat in the library.
						<li>3. Readers disobeying these rules will be asked to leave the facility immediately.
					</ol>
				</div>
				<div><h3>Services and Facilities</h3>
					<ol>The Library is open to the public.</ol>
				
				</div>
				
				<div><h3>Loans</h3>
					<ol>
					<li>1. Users may borrow an available book for 5 days maximum. 
					<li>2. They may also renew if the book is not in demand.
					<li>3. Overdue books are not to be renewed.
					</ol>
				</div>
<div><h3>Penalty</h3>
<ol>
	<li>Users must pay a fine of 50php a day for each overdue books.
	<li>Note: 3 Successive overdue may result into loss of privelege.
	</ol>
</div>
				<div>
					<h3>Losses and Mutilation</h3>
	<ol>
	<li> 1.Borrowers shall not write, mark, or tear the pages of any library Books.
	<li> 2.A fine will be charged for mutilation of books, according to the damage.
	<ol>			
	</div>
	</div>
				</div>
				</center>
					</div>
			</div>
			</div>
			</div>
			
			</div>
			</div>
			</div>
			</div>	
			</div>
			
	</div>

</div>
</div>
</body>
</html>
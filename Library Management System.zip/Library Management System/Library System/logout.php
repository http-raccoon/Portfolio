<?php
    ob_start();
        session_destroy();
        setcookie("UserCookie", null, -1);
        setcookie("UserType", $type, -1);
        header("Location: index.php");
    ob_end_flush();
?>
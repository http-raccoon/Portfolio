<?php	
    include "sqlconnection.php";
    $username=$_COOKIE['UserCookie'];
    $query1="SELECT * FROM userbase WHERE Username='$username'";
    $result1=mysqli_query($sqlcon, $query1);
    while($row=mysqli_fetch_array($result1)){
        $uid=$row['userID'];
    }
    //echo $uid;
    

    $Bookname = mysqli_real_escape_string($sqlcon, $_GET['bookname']);
    $bid = mysqli_real_escape_string($sqlcon, $_GET['bookid']);
    $userid = mysqli_real_escape_string($sqlcon, $uid);
    $checktable="SELECT * FROM requestedbooks WHERE userID='$userid'";
    $tableresult=mysqli_query($sqlcon, $checktable);
    if($bid=='' or $userid=''){
        echo '<script>alert("Field Cannot be Empty!")</script>';
        return false;
    }
    elseif(mysqli_num_rows($tableresult)>=1){
        echo '<script>alert("You have a pending request! Please wait for approval.")</script>';
        echo ("<script LANGUAGE='JavaScript'>
            window.location.href='viewbookreg.php';
            </script>");
        return false;
    }
    else{
        $statuscheck="SELECT Status FROM bookdb1 WHERE bookID='$bid'";
        $statusresult=mysqli_query($sqlcon, $statuscheck);
        while($row=mysqli_fetch_array($statusresult)){
        $status=$row['Status'];
        }
        if($status=="Available"){
            $sqlstring1="insert INTO requestedbooks(bookID, userID, Bookname, Username) VALUES ('$bid', '$uid', '$Bookname', '$username');";
            $sqlstring="update bookdb1 SET Status='Reserved' WHERE bookID='$bid'";
            mysqli_query($sqlcon, $sqlstring1);//sql for reserve table
            mysqli_query($sqlcon, $sqlstring);//DB, sql command
            mysqli_close($sqlcon);
            echo "<script>alert('Book Reserved, Please Proceed to the Librarian!')</script>";
            echo ("<script LANGUAGE='JavaScript'>
            window.location.href='viewbookreg.php';
            </script>");
        }
        else{
            echo '<script>alert("Book is Unavailable or Borrowed")</script>';
            echo ("<script LANGUAGE='JavaScript'>
            window.location.href='viewbookreg.php';
            </script>");
        }
    }

			
		
?>
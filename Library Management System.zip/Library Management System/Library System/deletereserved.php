<?php 
    include 'sqlconnection.php';
    $id = mysqli_real_escape_string($sqlcon, $_GET['bookid']);
    $rej = mysqli_query($sqlcon,"delete from requestedbooks where bookID='$id'"); // delete query
    $upd=mysqli_query($sqlcon, "update bookdb1 SET Status='Available' WHERE bookID='$id'");//update to available
    if($rej)
    {	
        mysqli_close($sqlcon);
        header("location:viewreserved.php");
        exit;	
    }
    else
    {
        echo "Error deleting Reservation, please try again.";
    }
?>
<?php
	session_start();
    require('./filecall.php'); 
	require "sqlconnection.php";
 
    if (!isset($_COOKIE['UserCookie'])){
		header('Location: index.php');
		exit;
	}
	if ($_COOKIE['UserType']=="Regular"){
		header('Location: regularform.php');
		exit;
	}
 
?>

<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
</head>

<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigation.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">Home / Dashboard</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, <?php echo $_COOKIE['UserCookie']; ?>!</p>
            </div>

            <div class="col-12 px-4 py-3" id="midMain">
                <div class="row">
                    <div class="col-12 col-md-5 d-flex flex-row mt-3" id="homecontent">
                        <div class="d-flex flex-row" style="width:100%;">
                            <div class="col-6 bg-danger" style="border-radius: 15px 0px 0px 15px;">
                                <span id="countericon">
                                <i class="fa-regular fa-id-card"></i></span>
                                <p class="mt-auto" id="counterLabel">Registered Users</p>
                            </div>
                            <div class="col-6 bg-warning" style="border-radius: 0px 15px 15px 0px;">
                                <p id="countnumber">
                                    <?php
                                        $query="SELECT * FROM userbase";
                                        $userresult=mysqli_query($sqlcon, $query);
                                        $count=mysqli_num_rows($userresult);
                                        echo "$count";
                                    ?>
                                </p>
                            </div>  
                        </div>        
                    </div>

                    <div class="col-12 col-md-5 d-flex flex-row mt-3" id="homecontent">
                        <div class="col-6 bg-danger" style="border-radius: 15px 0px 0px 15px;">
                            <span id="countericon">
                            <i class="fa-solid fa-book"></i></i></span>
                            <p class="mt-auto" id="counterLabel">Total Books Listed</p>
                        </div>
                        <div class="col-6 bg-warning" style="border-radius: 0px 15px 15px 0px;">
                            <p id="countnumber">
                                <?php
                                    $query="SELECT * FROM bookdb1";
                                    $userresult=mysqli_query($sqlcon, $query);
                                    $count=mysqli_num_rows($userresult);
                                    echo "$count";
                                ?>
                            </p>
                        </div>         
                    </div>

                    <div class="col-12 col-md-5 d-flex flex-row mt-3" id="homecontent">
                        <div class="col-6 bg-danger" style="border-radius: 15px 0px 0px 15px;">
                            <span id="countericon">
                            <i class="fa-solid fa-pen-to-square"></i></span>
                            <p class="mt-auto" id="counterLabel">Authors Listed</p>
                        </div>
                        <div class="col-6 bg-warning" style="border-radius: 0px 15px 15px 0px;">
                            <p id="countnumber">
                                <?php
                                    $query="SELECT * FROM bookdb1";
                                    $userresult=mysqli_query($sqlcon, $query);
                                    $count=mysqli_num_rows($userresult);
                                    echo "$count";
                                ?>
                            </p>
                        </div>         
                    </div>

                    <div class="col-12 col-md-5 d-flex flex-row mt-3" id="homecontent">
                        <div class="col-6 bg-danger" style="border-radius: 15px 0px 0px 15px;">
                            <span id="countericon">
                            <i class="fa-solid fa-address-book"></i></span>
                            <p class="mt-auto" id="counterLabel">Issued Books</p>
                        </div>
                        <div class="col-6 bg-warning" style="border-radius: 0px 15px 15px 0px;">
                            <p id="countnumber">
                                <?php
                                    $query="SELECT * FROM issuedbooks";
                                    $userresult=mysqli_query($sqlcon, $query);
                                    $count=mysqli_num_rows($userresult);
                                    echo "$count";
                                ?>
                            </p>
                        </div>         
                    </div>

                    <div class="col-12 col-md-5 d-flex flex-row mt-3 mb-1" id="homecontent">
                        <div class="col-6 bg-danger" style="border-radius: 15px 0px 0px 15px;">
                            <span id="countericon">
                            <i class="fa-solid fa-receipt"></i></i></span>
                            <p class="mt-auto" id="counterLabel">Total Transactions</p>
                        </div>
                        <div class="col-6 bg-warning" style="border-radius: 0px 15px 15px 0px;">
                            <p id="countnumber">
                                <?php
                                    $query="SELECT * FROM returnedrecords";
                                    $userresult=mysqli_query($sqlcon, $query);
                                    $count=mysqli_num_rows($userresult);
                                    echo "$count";
                                ?>
                            </p>
                        </div>         
                    </div>

                    <div class="col-12 col-md-5 d-flex flex-row mt-3 mb-1" id="homecontent">
                        <div class="col-6 bg-danger" style="border-radius: 15px 0px 0px 15px;">
                            <span id="countericon">
                            <i class="fa-solid fa-spinner"></i></span>
                            <p class="mt-auto" id="counterLabel">Pending Requests</p>
                        </div>
                        <div class="col-6 bg-warning" style="border-radius: 0px 15px 15px 0px;">
                            <p id="countnumber">
                                <?php
                                    $query="SELECT * FROM requestedbooks";
                                    $requestresult=mysqli_query($sqlcon, $query);
                                    $count=mysqli_num_rows($requestresult);
                                    echo "$count";
                                ?>
                            </p>
                        </div>         
                    </div>
                </div>   
            </div>     
        </div>
    </div>
</div>   
</body>


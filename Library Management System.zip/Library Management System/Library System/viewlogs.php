<?php
	session_start();
    require('./filecall.php'); 
	require "sqlconnection.php";
	
    if (!isset($_COOKIE['UserCookie'])){
		header('Location: index.php');
		exit;
	}
	if ($_COOKIE['UserType']=="Regular"){
		header('Location: regularform.php');
		exit;
	}
?>


<?php 
    function generaterecord(){
        include 'sqlconnection.php';
        $sqlstring="select * FROM logsdb ORDER BY LogsID DESC";
        echo "<form name='update' method='GET'>";
        $resultset=mysqli_query($sqlcon, $sqlstring);


        while($rowdata = mysqli_fetch_array($resultset))  
            {  
                echo "<tr>"; 
                    echo "<td>$rowdata[0]</td>";
					echo "<td>$rowdata[1]</td>";
                    echo "<td>$rowdata[2]</td>";
                 echo "</tr>";
            }  
        mysqli_close($sqlcon);
        
    }	
?>



<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
</head>

<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigation.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">View / Account Logs</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, <?php echo $_COOKIE['UserCookie']; ?>!</p>
            </div>

            <div class="col-12 p-2" id="midMain">
                
                <div class="col-12 overflow-auto" style="height: 79vh; background-color: #f2f2f2;">
                    <div class="p-3">  
                        <table id="ShowTable" class="table table-striped table-bordered">  
                                <thead class="table-dark" style="position: sticky; top: 0; z-index: 1;">
                                <tr>  
                                        <td id="vl">Log ID</td>  
                                        <td id="vl">Username</td>  
                                        <td id="vl">Date Stamp</td> 
                                </tr>  
                            </thead> 
                            <tbody> 
                                <?php
                                    echo generaterecord();
                                ?>
                            </tbody> 
                        </table>  
                    </div>
                </div> 
            </div>
                 
        </div>
    </div>
</div>   
</body>
<?php 
        include 'sqlconnection.php';
        
        $uid = $_GET['id'];
        $query = "select * from bookdb1 where bookID = '$uid'";
        $retrieve = mysqli_query($sqlcon,$query);
        if($row = mysqli_fetch_array($retrieve, MYSQLI_ASSOC)){

                $bookid = $row['bookID'];
                $bookname = $row['Bookname'];
                $author = $row['Author'];
                $genre = $row['Genre'];
                $isbn = $row['ISBN'];
                $status = $row['Status'];
                $publisher = $row['Publisher'];
                $publishdate = $row['PublishedDate'];
                $pageno = $row['PageNo'];
                $desc = $row['Description'];
                $archivedate = date("Y-m-d");
        
        $queryinsert = "INSERT INTO `archivedbooks`(`ArchiveID`, `bookID`, `Bookname`, `Author`, `Genre`, `ISBN`, `Status`, `Publisher`, `PublishedDate`, `PageNo`, `Description`, `Archive Date`) 
        VALUES ('',$bookid,'$bookname','$author','$genre','$isbn','$status','$publisher','$publishdate','$pageno','$desc','$archivedate')";

        $sqlinsert = mysqli_query($sqlcon,$queryinsert);

        
        // delete query
        $id = mysqli_real_escape_string($sqlcon, $uid);
        $del = mysqli_query($sqlcon,"delete from bookdb1 where bookID = '$id'"); 


        //go to other location

        mysqli_close($sqlcon);
        echo '<script>alert("Record Deleted!")</script>';
        echo ("<script LANGUAGE='JavaScript'>
        window.location.href='viewbook.php';
        </script>");
        
        }
        
?>    





<div class="col-md-2 d-none d-md-block" id="navMed" style="position: fixed;">
    <div class="row d-flex flex-column min-vh-100">
        <div class="col-12" id="navIcon">
            <img id="icon1" src="Images/malabonicon.png">
        </div>
        <div class="col-12" id="navLabel">
            <p id="labelss" style="font-size: 2.5vh;">Malabon City Library</p>
        </div>
        <button type="button" style="border-radius: 0; margin-top: 8vh;" id="navButtons" onclick="window.location.href = 'adminform.php';"><span class="icon"><i class="fas fa-home"></i></span>Home</button>
        <button type="button" style="border-radius: 0;" id="navactive" onclick="" class="buts"><span class="icon"><i class="fa-solid fa-eye"></i></span>View<span class="icon1"><i class="fa-solid fa-chevron-down"></i></span><span class="icon2"><i class="fa-solid fa-chevron-up"></i></span></button>
        <div class="submenu" style="background-color: #666;">
            <ul>
                <li><a id="sub" href="viewbook.php"><span class="item">Books</span></a></li>
                <li><a id="sub" href="viewusers.php"><span class="item">Users</span></a></li>
                <li><a id="sub" href="viewreserved.php"><span class="item">Book Request</span></a></li>
                <li><a id="sub" href="viewtransactions.php"><span class="item">Transaction Logs</span></a></li>
                <li><a id="sub" href="viewlogs.php"><span class="item">Account Logs</span></a></li>
                <li><a id="sub" href="archivedbooks.php"><span class="item">Archived Books</span></a></li>
                <li><a id="sub" href="archivedusers.php"><span class="item">Archived Users</span></a></li>
            </ul>
        </div>
        <button type="button" style="border-radius: 0;" id="navButtons" onclick="window.location.href = 'issuebook.php';"><span class="icon"><i class="fa-solid fa-person-walking-arrow-loop-left"></i></span>Issue Book</button>  
        <button type="button" style="border-radius: 0;" id="navButtons" onclick="window.location.href = 'returnbook.php';"><span class="icon"><i class="fa-solid fa-person-walking-arrow-loop-left"></i></span>Return Book</button>  
		<button type="button" style="border-radius: 0;" id="navButtons" onclick="window.location.href = 'faqs.php';"><span class="icon"><i class="fa-solid fa-book-bookmark"></i></span>Help Desk</button>
        <button type="button" style="border-radius: 0;" id="navButtons" onclick="window.location.href = 'logout.php';"><span class="icon"><i class="fa-solid fa-right-from-bracket"></i></span>Logout</button>  
        <footer class = "mt-auto" style="height: 4vh; background-color: #272727;"><p class="text-white mt-1">Version 1.0</p></footer>
    </div>
</div>


<div class="col-sm-12 d-block d-md-none d-flex flex-row" id="navSmalltitle"><img id="iconnavsmall" src="Images/malabonicon.png"></img><p id="NavTop">MALABON CITY LIBRARY</p></div>
    <div class="col-sm-12 d-block d-md-none" id="navSmall" style="position: sticky; top:0;">
        <div class="row d-flex flex-column">
            <div class="col-12 bg-danger" style="height: 7.5vh;">
                <div class="btn-group col-12 bg-danger h-100 container-fluid rounded-0" role="group" aria-label="Basic example">
                    <button type="button" id="navSButtons" class=" btn btn-danger rounded-0" onclick="window.location.href = 'dashboard.php';">Home</button>
                    
                    <button type="button" id="navSButtons" id="navbarDropdownMenuLink"  data-bs-toggle="dropdown" class="btn btn-danger rounded-0" style="height:100%;">View
                      <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li><a class="dropdown-item" href="viewbook.php">Books</a></li>
                        <li><a class="dropdown-item" href="viewusers.php">Users</a></li>
                        <li><a class="dropdown-item" href="viewreserved.php">Books Request</a></li>
                        <li><a class="dropdown-item" href="viewtransactions.php">Transaction Logs</a></li>
                        <li><a class="dropdown-item" href="viewlogs.php">Account Logs</a></li>
                      </ul>
                    <i class="fa-solid fa-chevron-down"></i>
                    </button>
                   
                    
                    <button type="button" id="navSButtons" id="navbarDropdownMenuLink"  data-bs-toggle="dropdown" class="btn btn-danger rounded-0">Issue
                      <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li><a class="dropdown-item" href="viewbook.php">Books</a></li>
                        <li><a class="dropdown-item" href="viewusers.php">Users</a></li>
                      </ul>
                    <i class="fa-solid fa-chevron-down"></i>
                    </button>
                    <button type="button" id="navSButtons" class="btn btn-danger rounded-0" onclick="window.location.href = 'product.php';">Return</button>
                    <button type="button" id="navSButtons" class="btn btn-danger rounded-0" onclick="window.location.href = 'dashboard.php';">Logout</button>
                </div>
            </div>
        </div>
    </div>


<script>
		var buts = document.querySelector(".buts");
		buts.addEventListener("click", function(){document.querySelector("body").classList.toggle("active1");})
        var buts = document.querySelector(".buts1");
		buts.addEventListener("click", function(){document.querySelector("body").classList.toggle("active2");})
</script>
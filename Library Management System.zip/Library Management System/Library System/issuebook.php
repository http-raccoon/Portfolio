<?php
	session_start();
    require('./filecall.php'); 
	require "sqlconnection.php";
 
    if (!isset($_COOKIE['UserCookie'])){
		header('Location: index.php');
		exit;
	}
	if ($_COOKIE['UserType']=="Regular"){
		header('Location: regularform.php');
		exit;
	}
 
?>
 
<?php 
    function generaterecord(){
        include 'sqlconnection.php';
        $sqlstring="select * FROM bookdb1 ORDER BY Bookname DESC";
        echo "<form name='update' method='GET'>";
        $resultset=mysqli_query($sqlcon, $sqlstring);
 
 
        while($rowdata = mysqli_fetch_array($resultset))  
            {  
                echo "<tr>"; 
                    echo "<td>$rowdata[0]</td>";
					echo "<td><a href='book.php?bookID=$rowdata[0]'>$rowdata[1]</a></td>";
					echo "<td>$rowdata[2]</td>";
                    echo "<td>$rowdata[3]</td>";
                    echo "<td>$rowdata[4]</td>";
                    echo "<td>$rowdata[5]</td>";
                    echo '<td><button onclick="get1('.$rowdata[0].')" class="btn btn-warning" style="font-size: 0.8em; width: 8vh;">Get</button></td>';
                    echo '</td>';
				        echo "</tr>";
            }  
        mysqli_close($sqlcon);
 
    }	
?>
 
<?php 
    function generaterecord1(){
        include 'sqlconnection.php';
        $sqlstring="select * FROM userbase ORDER BY userID DESC";
        echo "<form name='update' method='GET'>";
        $resultset=mysqli_query($sqlcon, $sqlstring);
 
 
        while($rowdata = mysqli_fetch_array($resultset))  
            {  
                echo "<tr>"; 
                    echo "<td>$rowdata[0]</td>";
					echo "<td>$rowdata[1]</td>";
                    echo "<td>$rowdata[3]</td>";
                    echo '<td><button onclick="get2('.$rowdata[0].')" class="btn btn-warning" style="font-size: 0.8em; width: 8vh;">Get</button></td>';
                    echo '</td>';
				    echo "</tr>";
            }  
        mysqli_close($sqlcon);
 
    }	
?>
 
 
 
<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
</head>
 
<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigation.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">View / Issue Books</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, <?php echo $_COOKIE['UserCookie']; ?>!</p>
            </div>
 
            <div class="col-12 p-3 row" id="midMain">
                <div class="col-md-3 col-sm-12 pb-3">
                    <div style="background-color:#f2f2f2;">
                        <div style="height:5vh; width:100%; background-color: #373b3e; color:fff;">
                            <p style="font-size:3.5vh; padding-left:6px;">ISSUE BOOK</p>
                        </div>
                        <div class="p-2">
                            <!--<form action="addbook.php" method="POST" enctype='multipart/form-data'>-->
                            <div class="form-group">
                                <label for="product-id" class="col-form-label">Book ID:</label>
                                <input type="text" class="form-control" id="book-id" name="add-id" readonly>
                            </div>
                            <div class="form-group">
                                <label for="product-id" class="col-form-label">User ID:</label>
                                <input type="text" class="form-control" id="user-id" name="add-id" readonly>
                            </div>
                            <div class="form-group">
                                <label for="product-id" class="col-form-label">Issue Date:</label>
                                <input type="text" class="form-control" id="issue-date" name="add-id" value="<?php echo date("Y-m-d")?>"readonly>
                            </div>
                            <div class="d-flex flex-column pt-3">
                            <button type="button" class="openupModal btn btn-warning" data-toggle="modal" data-target="#issueModal" style="padding-top:5px;">Submit</button>
                            </div>
                            <div class="d-flex flex-column pt-1">
                            <button onclick="cancel()" class="btn btn-danger" style="padding-top:5px;">Cancel</button>
                            </div>
                            <!--</form>-->
                        </div>
                    </div>
                </div>
                
                <div class="col-md-9 col-sm-12 column" style="height: 84vh;">
                <!--Show Books-->
                    <div style="height:5vh; width:100%; background-color: #373b3e; color:fff;">
                        <p style="font-size:3.5vh; padding-left:6px;">BOOKS</p>
                    </div>
                    <div class="overflow-auto" style="height: 37vh; width:100%; background-color: #f2f2f2;">
                        <div class="p-2">
                            <table id="ShowBooks" class="table1 table-striped table-bordered" style="border: 1px solid; border-color:#dee2e6; width:100%;">  
                                    <thead class="table-dark" style="position: sticky; top: 0; z-index: 1; border: 1px solid; border-color:#373b3e; background-color:#212529;">
                                    <tr style="padding:100px;">  
                                            <td id="">BookID</td>  
                                            <td id="">BookName</td>  
                                            <td id="">Author</td>  
                                            <td id="">Genre</td>  
                                            <td id="">ISBN</td>  
                                            <td id="">Status</td>
                                            <td id="">Get Book</td>  
                                    </tr>  
                                </thead> 
                                <tbody> 
                                    <?php
                                        echo generaterecord();
                                    ?>
                                </tbody> 
                            </table>  
                        </div>
                    </div> 
 
                    <!--Show Users-->
                    <div style="height:5vh; width:100%; background-color: #373b3e; color:fff;">
                        <p style="font-size:3.5vh; padding-left:6px;">USERS</p>
                    </div>
                    <div class="overflow-auto" style="height: 37vh; width:100%; background-color: #f2f2f2;">
                        <div class="p-2">
                            <table id="ShowUsers" class="table1 table-striped table-bordered" style="border: 1px solid; border-color:#dee2e6; width:100%;">  
                                    <thead class="table-dark" style="position: sticky; top: 0; z-index: 1; border: 1px solid; border-color:#373b3e; background-color:#212529;">
                                    <tr style="padding:100px;">  
                                            <td id="">User ID</td>  
                                            <td id="">Username</td>  
                                            <td id="">Name</td> 
                                            <td id="">Get User</td>  
                                    </tr>  
                                </thead> 
                                <tbody> 
                                    <?php
                                        echo generaterecord1();
                                    ?>
                                </tbody> 
                            </table>  
                        </div>
                    </div>
 
 
                </div>             
            </div>     
        </div>
    </div>
</div>   
 
</body>

<!-- Modal Return-->
<div class="modal fade" id="issueModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Confirm</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="border:0; background: 000;">
        <span aria-hidden="true"><i class="fa-sharp fa-solid fa-xmark"></i></span>
        </button>
      </div>
      <div class="modal-body">
            Are you sure you want to Issue this book?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button onclick="submit()" class="btn btn-warning">Okey</button>
      </div>
    </div>
  </div>
</div>
 
 
<!-- for modal -->
<script type="text/javascript">
    
    function get1(id){
        document.getElementById('book-id').value = id;
    }
    function get2(id){
        document.getElementById('user-id').value = id;
    }
    function cancel(){
        document.getElementById('book-id').value = " ";
        document.getElementById('user-id').value = " ";
    }
    function submit(){
        var bookid1 = document.getElementById("book-id").value;
        var userid1 = document.getElementById("user-id").value;
        var issuedate1 = document.getElementById("issue-date").value;
        var pathh = "issuebookfunction.php?bi="+bookid1+" & ui="+userid1+" & id="+issuedate1+" ";
        window.location.href = pathh;
    }

</script>
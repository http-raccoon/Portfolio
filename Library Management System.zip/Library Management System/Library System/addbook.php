<?php
    include 'sqlconnection.php';
    $isbn = mysqli_real_escape_string($sqlcon, $_GET['isbn']);
    $bname= mysqli_real_escape_string($sqlcon, $_GET['bname']);
    $author= mysqli_real_escape_string($sqlcon, $_GET['author']);
    $category= mysqli_real_escape_string($sqlcon, $_GET['category']);
    $publisher = mysqli_real_escape_string($sqlcon, $_GET['publisher']);
    $published = mysqli_real_escape_string($sqlcon, $_GET['published']);
    $pages = mysqli_real_escape_string($sqlcon, $_GET['pagec']);
    $description = mysqli_real_escape_string($sqlcon, $_GET['description']);
    $status="Available";
    
    if($bname=='' or $author=='' or $category=='' or $isbn==''){
        echo '<script>alert("Field Cannot be Empty!")</script>';
    }
    else{
        $sqlstring="insert INTO bookdb1(`Bookname`, `Author`, `Genre`, `ISBN`, `Status`, `Publisher`, `PublishedDate`, `PageNo`, `Description`) VALUES ('$bname','$author','$category','$isbn','$status', '$publisher', '$published', '$pages', '$description')";
        mysqli_query($sqlcon, $sqlstring);
        mysqli_close($sqlcon);
        echo '<script>alert("Book successfully added!")</script>';
        echo ("<script LANGUAGE='JavaScript'>window.location.href='viewbook.php';</script>");
    }	
?>
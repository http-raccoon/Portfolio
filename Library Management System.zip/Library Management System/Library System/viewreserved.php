<?php
	session_start();
    require('./filecall.php'); 
	require "sqlconnection.php";
	
    if (!isset($_COOKIE['UserCookie'])){
		header('Location: index.php');
		exit;
	}
	if ($_COOKIE['UserType']=="Regular"){
		header('Location: regularform.php');
		exit;
	}
?>


<?php 
    function generaterecord(){
        include 'sqlconnection.php';
        $sqlstring="select * FROM requestedbooks ORDER BY RequestID DESC";
        echo "<form name='update' method='GET'>";
        $resultset=mysqli_query($sqlcon, $sqlstring);


        while($rowdata = mysqli_fetch_array($resultset))  
            {  
                echo "<tr>"; 
                    echo "<td>$rowdata[0]</td>";
                    echo "<td>$rowdata[2]</td>";
                    echo "<td>$rowdata[1]</td>";
                    echo "<td>$rowdata[3]</td>";
                    echo "<td>$rowdata[4]</td>";
                    echo '<td><button style="font-size: 0.8em; width: 8vh;" type="button" class="openupModal btn btn-warning" data-toggle="modal" data-target="#updateModal">Accept</button>&nbsp';
                    echo '<button style="font-size: 0.8em; width: 8vh;" type="button" class="opendelModal btn btn-Danger" data-toggle="modal" data-target="#deleteModal">Delete</button></td>';
			    echo "</tr>";
            }  
        mysqli_close($sqlcon);
        
    }	
?>



<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
	<script>
	function printtest(){
		var divToPrint=document.getElementById("ShowTable");
		newWin= window.open("");
		newWin.document.write(divToPrint.outerHTML);
		newWin.print();
		newWin.close();
	}
	</script>
</head>

<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigation.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">View / Account Logs</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, <?php echo $_COOKIE['UserCookie']; ?>!</p>
            </div>

            <div class="col-12 p-2" id="midMain">
                
                <div class="col-12 overflow-auto" style="height: 79vh; background-color: #f2f2f2;">
                    <div class="p-3">  
                        <table id="ShowTable" class="table table-striped table-bordered">  
                                <thead class="table-dark" style="position: sticky; top: 0; z-index: 1;">
                                <tr>  
                                        <td id="">Request ID</td>  
                                        <td id="">User ID</td>  
                                        <td id="">Book ID</td> 
                                        <td id="">Book Name</td>  
                                        <td id="">Username</td>  
                                        <td id="">Accept / Reject</td> 
                                </tr>  
                            </thead> 
                            <tbody> 
                                <?php
                                    echo generaterecord();
                                ?>
                            </tbody> 
                        </table>  
                    </div>
                </div>
				<div class="d-flex flex-column-reverse">
                    <div class="align-self-end">
                         <button class="btn btn-primary" style="vertical-align:middle; margin-top:10px; margin-right:30px; width: 30vh;" onclick="printtest()">Print Table Page</button>
                    </div>
                </div>				
            </div>
                 
        </div>
    </div>
</div>   
</body>

<!-- Modal Delete-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="productname"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="border:0; background: 000;">
        <span aria-hidden="true"><i class="fa-sharp fa-solid fa-xmark"></i></span>
        </button>
      </div>
      <div class="modal-body">
            Are you sure you want to delete this reserve?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a id="delete"><button class="btn btn-danger">Delete</button></a>
      </div>
    </div>
  </div>
</div>

<!-- Modal Accept-->
<div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="productname1"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="border:0; background: 000;">
        <span aria-hidden="true"><i class="fa-sharp fa-solid fa-xmark"></i></span>
        </button>
      </div>
      <div class="modal-body">
            Are you sure you want to accept this reserve?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a id="accept"><button class="btn btn-danger">Accept</button></a>
      </div>
    </div>
  </div>
</div>



<!-- for modal -->
<script type="text/javascript">
    $("#ShowTable").on('click','.opendelModal',function () {
        var currentRow=$(this).closest("tr");
        var id = currentRow.find("td:eq(0)").text();
        var bookid = currentRow.find("td:eq(2)").text();
        document.getElementById("productname").innerHTML = id;
        document.getElementById("delete").href = "deletereserved.php?bookid=".concat(bookid);
    });
    $("#ShowTable").on('click','.openupModal',function () {
        var currentRow=$(this).closest("tr");
        var id = currentRow.find("td:eq(0)").text();
        var userid = currentRow.find("td:eq(1)").text();
        var bookid = currentRow.find("td:eq(2)").text();
        document.getElementById("productname1").innerHTML = id;
        document.getElementById("accept").href = "acceptreserved.php?userid="+userid+" & bookid="+bookid+" ";
        
    });
</script>
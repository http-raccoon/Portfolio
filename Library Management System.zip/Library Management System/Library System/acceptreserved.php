<?php
    include 'sqlconnection.php';
    $bookid = mysqli_real_escape_string($sqlcon, $_GET['bookid']);
    $userid = mysqli_real_escape_string($sqlcon, $_GET['userid']);
    //$issuedate = mysqli_real_escape_string($sqlcon, date("Y-m-d");
    $date = date("Y-m-d");
    $sqluid="SELECT * FROM userbase WHERE userID='$userid'";
    $uidresult=mysqli_query($sqlcon, $sqluid);
    if(mysqli_num_rows($uidresult) == 0){
        echo '<script>alert("UserID does not exist")</script>';
        return false;
    }
    else{
        $sqlstatus= "SELECT * FROM issuedbooks WHERE BookID='$bookid'";
        $statusresult = mysqli_query($sqlcon, $sqlstatus);
        if(mysqli_num_rows($statusresult) >=1){
            echo '<script>alert("Book Not Available at the moment")</script>';
            return false;
        }
        $reservedstatus = "SELECT * FROM requestedbooks where BookID='$bookid'";
        $reservedresult = mysqli_query($sqlcon, $reservedstatus);
        if(mysqli_num_rows($statusresult) >=1){
            echo '<script>alert("Book Not Available at the moment")</script>';
            return false;
        }
        else{
            $del = mysqli_query($sqlcon, "delete from requestedbooks where bookID='$bookid'"); // delete query
            $upd=mysqli_query($sqlcon, "update bookdb1 SET Status='Unavailable' WHERE bookID='$bookid'"); //update to unavailable
            $acc=mysqli_query($sqlcon, "insert INTO issuedbooks (BookID, UserID, IssueDate) VALUES ($bookid,'$userid', '$date')"); //insert, accept
            if($acc)
            {	
                mysqli_close($sqlcon);
                header("location:viewreserved.php");
                exit;	
            }
            else
            {
                echo '<script>alert("Error processing Reservation, please try again.")</script>';
            }
        }
    }
		
?>
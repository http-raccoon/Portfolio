<?php 
    include 'sqlconnection.php';
    $issueID = mysqli_real_escape_string($sqlcon, $_GET['issueid']);
    $bookid = mysqli_real_escape_string($sqlcon, $_GET['bookid']);
    $userid = mysqli_real_escape_string($sqlcon, $_GET['userid']);
    $issuedate = mysqli_real_escape_string($sqlcon, $_GET['issuedate']);
    $returndate = mysqli_real_escape_string($sqlcon, $_GET['returndate']);
    if($userid=='' or $bookid=='' or $issuedate==''){
        echo '<script>alert("Field Cannot be Empty!")</script>';
        return false;
    }
    else{
        $sqlbook="SELECT * FROM issuedbooks WHERE bookID='$bookid'";
        $bookresult=mysqli_query($sqlcon, $sqlbook);
        if(mysqli_num_rows($bookresult) == 0){
            echo '<script>alert("Book is currently not issued")</script>';
            return false;
        }
        else{
            $sqluid="SELECT * FROM issuedbooks WHERE UserID='$userid' AND BookID='$bookid' AND IssueDate='$issuedate'";
            $uidresult=mysqli_query($sqlcon, $sqluid);
            if(mysqli_num_rows($uidresult) == 0){
                echo '<script>alert("Details Mismatch, please try again")</script>';
                return false;
            }
            else{
                $startTimeStamp = strtotime($_GET['issuedate']); //issued
                $dueTimeStamp = strtotime(date("Y-m-d", strtotime($_GET['issuedate']. '+ 5 days'))); //due date, +5 days after issued
                $endTimeStamp = strtotime($_GET['returndate']); //return date
                $timeDiff = ($endTimeStamp - $dueTimeStamp); //difference in seconds
                $numberDays = $timeDiff/86400;  // converted to day
                $numberDays = intval($numberDays);
                if($numberDays > 0){
                    $penalty = $numberDays*50;
                }
                else{
                    $penalty = 0;
                }
                $sqlstring="delete FROM issuedbooks WHERE issueID=$issueID; ";
                $sqlstring2="update `bookdb1` SET `Status`='Available' WHERE bookID=$bookid";
    //$sqlstring3="insert INTO returnedrecords values('$issueid', '$bookid', '$userid', '$returndate');";
                $sqlstring3="insert INTO returnedrecords (IssueID, BookID, UserID, ReturnDate, Penalty) VALUES ('$issueID','$bookid', '$userid', '$returndate', '$penalty');";
                mysqli_query($sqlcon, $sqlstring);
                mysqli_query($sqlcon, $sqlstring2);
                mysqli_query($sqlcon, $sqlstring3);
                mysqli_close($sqlcon);
                echo "<script>alert('Total Penalty of this Transaction: ₱ $penalty (Book successfully returned!)')</script>";
                echo ("<script LANGUAGE='JavaScript'>window.location.href='returnbook.php';</script>");
            }
        }
    }

    
 
?>
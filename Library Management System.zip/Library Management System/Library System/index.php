<?php
	session_start();
	ob_start();
	require('./filecall.php');
	require "sqlconnection.php";
	
	if (isset($_COOKIE['UserCookie'])){
		if (($_COOKIE['UserType']=="Admin")){
			header('Location: adminform.php');
			exit();
		}
		elseif($_COOKIE['UserType']=="Regular"){
			header('Location: regularform.php');
			exit();
		}
	}
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Malabon City Library</title>
    <meta charset="utf-8">
	<link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="CSSLOGIN.css">
   

    
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

	<script src="https://kit.fontawesome.com/c5a8523ccd.js" crossorigin="anonymous"></script>
	<style type="text/css">
		@import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;1,100;1,200;1,300;1,400;1,500&family=Open+Sans:wght@300&family=Roboto:wght@100&display=swap');
	</style> 
	

	<?php
	function login(){
		include "sqlconnection.php";
		$username = $_POST['txtUsername'];
		$password = $_POST['txtPassword'];
		if($username=='' or $password==''){
			echo '<script>alert("Field Cannot be Empty!")</script>';
			return false;
		}
		
		else{
			$sqluser="SELECT * FROM userbase WHERE Username='$username'";
			$userresult=mysqli_query($sqlcon, $sqluser);
			if(mysqli_num_rows($userresult) == 0){
				echo '<script>alert("User Does not Exist")</script>';
				return false;
			}
			else{
				$sqlpass="SELECT * FROM userbase WHERE Username='$username' AND Password='$password'";
				$passresult=mysqli_query($sqlcon, $sqlpass);
				if(mysqli_num_rows($passresult) == 0){
					echo '<script>alert("Password is incorrect")</script>';
					return false;
				}
				else{
					$query1="SELECT Type FROM userbase WHERE Username='$username' AND Password='$password'";
					$result1=mysqli_query($sqlcon, $query1);
					while($row=mysqli_fetch_array($result1)){
						$type=$row['Type'];
					}
					$query="SELECT * FROM userbase WHERE Username='$username' AND Password='$password'";
					$result=mysqli_query($sqlcon, $query);
					while($row=mysqli_fetch_array($result)){
						if($row['Username']==$username && $row['Password']==$password && $type=="Admin"){
							setcookie("UserCookie", $username, time()+86400);
							setcookie("UserType", $type, time()+86400);
							$datestamp = mysqli_real_escape_string($sqlcon, date("Y-m-d"));
							$logsquery = "insert INTO logsdb (UserID, DateStamp) VALUES ('$username', '$datestamp');";
							mysqli_query ($sqlcon, $logsquery);
							header("Location: adminform.php");
						}
						elseif($row['Username']==$username && $row['Password']==$password && $type=="Regular"){
							setcookie("UserCookie", $username, time()+86400);
							setcookie("UserType", $type, time()+86400);
							$datestamp = mysqli_real_escape_string($sqlcon, date("Y-m-d"));
							$logsquery1 = "insert INTO logsdb (UserID, DateStamp) VALUES ('$username', '$datestamp');";
							mysqli_query ($sqlcon, $logsquery1);
							header("Location: regularform.php");
						}
						else{
							echo '<script>alert("User detail is wrong, please try again")<script>';
						}
					}	
				}
			}
		}
	}
	?>



</head>
<body>

	<div class="container">
		<div class="row px-3">
			<div class="col-lg-10 col-xl-9 card flex-row mx-auto px-0">
				<div class="img-left d-none d-md-flex">
				</div>
				<div class="card-body">
						<center><img src="images/logo.png" style="width: 8rem; padding-top: 1.1vh;"></center>
					<h2 class="text-center mb-2 mt-3 tit">
						MALABON CITY LIBRARY
					</h2>

					
					<form method="POST">
						<div class="form-input">
							<span><i class="fas fa-id-card"></i></span>
							<input type="text" name="txtUsername" placeholder="Username" required>
								
						
						</div>

						<div class="form-input">
							<span><i class="fa fa-key"></i></span>
							<input type="password" name="txtPassword" placeholder="Password" required>
						</div>

						<div class="mb-3">
							<div class="custom-control custom-checkbox">
                            <a href="guest.php">Guest?</a>
						</div>
						</div>



						<div class="mb-3">
							<center><button type="submit" name="Login" class="btn btn-block text-uppercase" id="what">Login</button></center>
							
		
						</div>


						<hr class="my-2">
						 <div class="text-center mb-1">
						</div> 
					</form>
				</div>
			</div>
		</div>
	</div>

</body>
</html>

<?php
	
	if(isset($_POST['Login'])){
		login();
	}
	
?>



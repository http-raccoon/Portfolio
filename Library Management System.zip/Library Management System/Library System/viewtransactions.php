<?php
	session_start();
    require('./filecall.php'); 
	require "sqlconnection.php";
	
    if (!isset($_COOKIE['UserCookie'])){
		header('Location: index.php');
		exit;
	}
	if ($_COOKIE['UserType']=="Regular"){
		header('Location: regularform.php');
		exit;
	}
?>


<?php 
    function generaterecord(){
        include 'sqlconnection.php';
        $sqlstring="select * FROM returnedrecords ORDER BY ReturnID DESC";
        echo "<form name='update' method='GET'>";
        $resultset=mysqli_query($sqlcon, $sqlstring);


        while($rowdata = mysqli_fetch_array($resultset))  
            {  
                echo "<tr>"; 
                    echo "<td>$rowdata[0]</td>";
					echo "<td>$rowdata[1]</td>";
                    echo "<td>$rowdata[2]</td>";
                    echo "<td>$rowdata[3]</td>";
                    echo "<td>$rowdata[4]</td>";
                    echo "<td>$rowdata[5]</td>";
                 echo "</tr>";
            }  
        mysqli_close($sqlcon);
        
    }	
?>



<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
    <style type="text/css">
        @media print{
        table td:last-child, th:last-child{
          display:none!important;
          }
        }
    </style>
	<script>
	function printtest(){
		var divToPrint=document.getElementById("ShowTable");
		newWin= window.open("");
		newWin.document.write(divToPrint.outerHTML);
		newWin.print();
		newWin.close();
	}
	</script>
</head>

<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigation.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">View / Transactions Logs</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, <?php echo $_COOKIE['UserCookie']; ?>!</p>
            </div>

            <div class="col-12 p-2" id="midMain">
                
                <div class="col-12 overflow-auto" style="height: 79vh; background-color: #f2f2f2;">
                    <div class="p-3">  
                        <table id="ShowTable" class="table table-striped table-bordered">  
                                <thead class="table-dark" style="position: sticky; top: 0; z-index: 1;">
                                <tr>  
                                        <td id="vt">Transaction ID</td>  
                                        <td id="vt">Issue ID</td>  
                                        <td id="vt">Book ID</td> 
                                        <td id="vt">User ID</td>  
                                        <td id="vt">Return Date</td>  
                                        <td id="vt">Penalty</td>  
                                </tr>  
                            </thead> 
                            <tbody> 
                                <?php
                                    echo generaterecord();
                                ?>
                            </tbody> 
                        </table>  
                    </div>
                </div> 
                <div class="d-flex flex-column-reverse">
                    <div class="align-self-end">
                         <button class="btn btn-primary" style="vertical-align:middle; margin-top:10px; margin-right:30px; width: 30vh;" onclick="printtest()">Print Table Page</button>
                    </div>
                </div>
                
                
            </div>
                 
        </div>
    </div>
</div>   
</body>
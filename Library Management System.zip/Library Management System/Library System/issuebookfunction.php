<?php 
    include "sqlconnection.php";
    $userid =  mysqli_real_escape_string($sqlcon, $_GET['ui']);
    $bookid = mysqli_real_escape_string($sqlcon, $_GET['bi']);
    $issuedate = mysqli_real_escape_string($sqlcon, $_GET['id']);
    
    if($userid=='' or $bookid=='' or $issuedate==''){
        echo '<script>alert("Field Cannot be Empty!")</script>';
        echo ("<script LANGUAGE='JavaScript'>window.location.href='issuebook.php';</script>");
    }
    else{
        $sqlbook="SELECT * FROM bookdb1 WHERE bookID='$bookid'";
        $bookresult=mysqli_query($sqlcon, $sqlbook);
        if(mysqli_num_rows($bookresult) == 0){
            echo '<script>alert("Book does not exist")</script>';
            echo ("<script LANGUAGE='JavaScript'>window.location.href='issuebook.php';</script>");
        }
        else{
            $sqluid="SELECT * FROM userbase WHERE userID='$userid'";
            $uidresult=mysqli_query($sqlcon, $sqluid);
            if(mysqli_num_rows($uidresult) == 0){
                echo '<script>alert("UserID does not exist")</script>';
                echo ("<script LANGUAGE='JavaScript'>window.location.href='issuebook.php';</script>");
            }
            else{
                $sqlstatus="SELECT * FROM issuedbooks WHERE BookID='$bookid'";
                $statusresult=mysqli_query($sqlcon, $sqlstatus);
                $reservedstatus = "SELECT * FROM requestedbooks  where BookID='$bookid'";
                $reservedresult = mysqli_query($sqlcon, $reservedstatus);
                if(mysqli_num_rows($statusresult) >=1){
                    echo '<script>alert("Book Not Available at the moment")</script>';
                    echo ("<script LANGUAGE='JavaScript'>window.location.href='issuebook.php';</script>");
                }
                elseif(mysqli_num_rows($reservedresult) >=1){
                    echo '<script>alert("Book already reserved, please approve or reject first")</script>';
                    echo ("<script LANGUAGE='JavaScript'>window.location.href='issuebook.php';</script>");
                }									
                else{
                    $sqlstring="insert INTO issuedbooks (BookID, UserID, IssueDate) VALUES ($bookid,'$userid', '$issuedate');";
                    mysqli_query($sqlcon, $sqlstring);
                    $sqlstup="update `bookdb1` SET `Status`='Borrowed' WHERE bookID=$bookid;";
                    mysqli_query($sqlcon, $sqlstup);
                    mysqli_close($sqlcon);
                    echo '<script>alert("Book successfully issued!")</script>';
                    echo ("<script LANGUAGE='JavaScript'>window.location.href='issuebook.php';</script>");
                }	
            }
        }
    }


?>
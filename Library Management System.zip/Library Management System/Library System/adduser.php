<?php
    include "sqlconnection.php";
    $un= mysqli_real_escape_string($sqlcon, $_GET['un']);
    $pass= mysqli_real_escape_string($sqlcon,$_GET['pass']);
    $name= mysqli_real_escape_string($sqlcon, $_GET['name']);
    $type= mysqli_real_escape_string($sqlcon, $_GET['type']);
    
    if($un==" " or $pass==" " or $name==" " or $type==" "){
        echo '<script>alert("Field Cannot be Empty!")</script>';
        echo ("<script LANGUAGE='JavaScript'>window.location.href='viewusers.php';</script>");
    }
    else{
        $sqlstring="insert INTO userbase(`Username`, `Password`, `Name`, `Type`) VALUES ('$un','$pass','$name','$type')";
        mysqli_query($sqlcon, $sqlstring);
        mysqli_close($sqlcon);
        echo '<script>alert("Account successfully added!")</script>';
        echo ("<script LANGUAGE='JavaScript'>window.location.href='viewusers.php';</script>");
    }	
?>
<?php 
        include 'sqlconnection.php';
        
        $uid = $_GET['id'];
        $query = "select * from userbase where userID = '$uid'";
        $retrieve = mysqli_query($sqlcon,$query);
        if($row = mysqli_fetch_array($retrieve, MYSQLI_ASSOC)){
                $userid = $row['userID'];
                $username = $row['Username'];
                $password = $row['Password'];
                $name = $row['Name'];
                $type = $row['Type'];
                $archivedate = date("Y-m-d");
        
        $queryinsert = "INSERT INTO `archivedusers`(`ArchiveID`, `userID`, `Username`, `Password`, `Name`, `Type`, `Archive Date`) 
        VALUES ('',$userid,'$username','$password','$name','$type','$archivedate')";

        $sqlinsert = mysqli_query($sqlcon,$queryinsert);

        
        // delete query
        $id = mysqli_real_escape_string($sqlcon, $uid);
        $del = mysqli_query($sqlcon,"delete from userbase where userID = '$id'"); 


        //go to other location

        mysqli_close($sqlcon);
        echo '<script>alert("Record Deleted!")</script>';
        echo ("<script LANGUAGE='JavaScript'>
        window.location.href='viewusers.php';
        </script>");

        }
?>    

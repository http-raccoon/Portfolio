<?php
	session_start();
	require('./filecall.php'); 
	require "sqlconnection.php";
	if (!isset($_COOKIE['UserCookie'])){
		header('Location: index.php');
		exit;
	}
	if ($_COOKIE['UserType']=="Admin"){
		header('Location: adminform.php');
		exit;
	}
?>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
</head>

<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigationuser.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">Home / Dashboard</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, <?php echo $_COOKIE['UserCookie']; ?>!</p>
            </div>

            <div class="col-12 px-4 py-3" id="midMain">
                <div class="row">


                    <div class="col-12 col-md-5 d-flex flex-row mt-3" id="homecontent">
                        <div class="col-6 bg-danger" style="border-radius: 15px 0px 0px 15px;">
                            <span id="countericon">
                            <i class="fa-solid fa-book"></i></i></span>
                            <p class="mt-auto" id="counterLabel">Total Books Listed</p>
                        </div>
                        <div class="col-6 bg-warning" style="border-radius: 0px 15px 15px 0px;">
                            <p id="countnumber">
                                <?php
                                    $query="SELECT * FROM bookdb1";
                                    $userresult=mysqli_query($sqlcon, $query);
                                    $count=mysqli_num_rows($userresult);
                                    echo "$count";
                                ?>
                            </p>
                        </div>         
                    </div>

                    <div class="col-12 col-md-5 d-flex flex-row mt-3" id="homecontent">
                        <div class="col-6 bg-danger" style="border-radius: 15px 0px 0px 15px;">
                            <span id="countericon">
                            <i class="fa-solid fa-pen-to-square"></i></span>
                            <p class="mt-auto" id="counterLabel">Authors Listed</p>
                        </div>
                        <div class="col-6 bg-warning" style="border-radius: 0px 15px 15px 0px;">
                            <p id="countnumber">
                                <?php
                                    $query="SELECT * FROM bookdb1";
                                    $userresult=mysqli_query($sqlcon, $query);
                                    $count=mysqli_num_rows($userresult);
                                    echo "$count";
                                ?>
                            </p>
                        </div>         
                    </div>

                    <div class="col-12 col-md-5 d-flex flex-row mt-3" id="homecontent">
                        <div class="col-6 bg-danger" style="border-radius: 15px 0px 0px 15px;">
                            <span id="countericon">
                            <i class="fa-solid fa-pen-to-square"></i></span>
                            <p class="mt-auto" id="counterLabel">My Books</p>
                        </div>
                        <div class="col-6 bg-warning" style="border-radius: 0px 15px 15px 0px;">
                            <p id="countnumber">
                                <?php
                                    $username=$_COOKIE['UserCookie'];
                                    $query1="SELECT userID FROM userbase WHERE Username='$username'";
                                        $result1=mysqli_query($sqlcon, $query1);
                                        while($row=mysqli_fetch_array($result1)){
                                            $uid=$row['userID'];
                                        }
                                    $sqlstring="select * FROM issuedbooks WHERE UserID=$uid";
                                    $bookresult=mysqli_query($sqlcon, $sqlstring);
                                    $mybookcount=mysqli_num_rows($bookresult);
                                    echo "$mybookcount";
                                ?>
                            </p>
                        </div>         
                    </div>

                    <div class="col-12 col-md-5 d-flex flex-row mt-3" id="homecontent">
                        <div class="col-6 bg-danger" style="border-radius: 15px 0px 0px 15px;">
                            <span id="countericon">
                            <i class="fa-solid fa-book"></i></i></span>
                            <p class="mt-auto" id="counterLabel">Total Books Returned</p>
                        </div>
                        <div class="col-6 bg-warning" style="border-radius: 0px 15px 15px 0px;">
                            <p id="countnumber">
                                <?php
                                    $username=$_COOKIE['UserCookie'];
                                    $query1="SELECT userID FROM userbase WHERE Username='$username'";
                                        $result1=mysqli_query($sqlcon, $query1);
                                        while($row=mysqli_fetch_array($result1)){
                                            $uid=$row['userID'];
                                        }
                                    $sqlstring="select * FROM returnedrecords WHERE UserID=$uid";
                                    $bookresult=mysqli_query($sqlcon, $sqlstring);
                                    $mybookcount=mysqli_num_rows($bookresult);
                                    echo "$mybookcount";
                                ?>
                            </p>
                        </div>         
                    </div>

                    

                    
                </div>   
            </div>     
        </div>
    </div>
</div>   
</body>
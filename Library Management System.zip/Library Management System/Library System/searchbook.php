<?php
	session_start();
    require('./filecall.php'); 
	require "sqlconnection.php";
 
    if (!isset($_COOKIE['UserCookie'])){
		header('Location: index.php');
		exit;
	}
	if ($_COOKIE['UserType']=="Regular"){
		header('Location: regularform.php');
		exit;
	}
 
?>

<?php 
    $isbn = "";
    $title = "";
    $author = "";
    $category = "";
    $publisher = ""; 
    $published = "";
    $pages = "";
    $description  = "";
        if(isset($_POST['search'])){
            if(!empty($_POST['isbn'])){
                if(strlen($_POST['isbn']) == 10 or strlen($_POST['isbn']) == 13){		
                $isbn_url = 'https://www.googleapis.com/books/v1/volumes?q=isbn:' . $_POST['isbn'];
                $isbn_json = file_get_contents($isbn_url);	
                $isbn_array = json_decode($isbn_json, true);
                    if($isbn_array['totalItems']!=0){
                        $isbn = $_POST['isbn'];
                        $title = $isbn_array['items'][0]['volumeInfo']['title'];
                        $author = $isbn_array['items'][0]['volumeInfo']['authors'][0];
                        $category = $isbn_array['items'][0]['volumeInfo']['categories'][0];
                        $publisher = $isbn_array['items'][0]['volumeInfo']['publisher']; 
                        $published = $isbn_array['items'][0]['volumeInfo']['publishedDate'];
                        if(array_key_exists("pageCount", $isbn_array['items'][0]['volumeInfo'])){	
                            $pages = $isbn_array['items'][0]['volumeInfo']['pageCount'];
                        }
                        else{
                            $pages = "not found";
                        }
                        if(array_key_exists("description", $isbn_array['items'][0]['volumeInfo'])){	
                            $description = $isbn_array['items'][0]['volumeInfo']['description'];
                        }
                        else{
                            $description = "not found";
                        }
                    }
                    else{
                        echo '<script> alert("Book not found in API")</script>';
                    }
                }
                else{
                    echo '<script> alert("Please enter ISBN 10 or 13")</script>';
                }
            }	
            else{
                echo '<script> alert("ISBN cannot be blank")</script>';
            }
        }
?>

<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
</head>

<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigation.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">Home / Dashboard</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, <?php echo $_COOKIE['UserCookie']; ?>!</p>
            </div>

            <div class="col-12 px-4 py-3">
                <div class="col-12 row">
                    <div class="col-3">
                        <!--SPACER-->
                    </div>
                    <div class="col-6 px-4 py-3" style="background-color: #f2f2f2;">
                    <div class="d-flex flex-column-reverse pb-2">
                        <div class="align-self-end">
                        <button type="button" style="border:0; background:000;" onclick="window.location.href = 'viewbook.php';">
                                <span><i class="fa-sharp fa-solid fa-xmark"></i></span>
                        </button>
                        </div>
                    </div>
                        <div class="col-12 px-3 py-3" style="border-radius: 25px; background-color: #e6e6e6;">
                            <h3>BOOK DETAILS</h3>
                            <form name="ADD" method='POST'>
                                <div class="form-group">
                                    <label for="add-id" class="col-form-label">Book ID:</label>
                                    <input type="text" class="form-control" id="add-id" name="add-id" placeholder="Automatically Generated" readonly>
                                </div>

                                <label for="product-id" class="col-form-label">ISBN:</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="isbn" name="isbn" value="<?php if(isset($_POST['search'])) echo $isbn; ?>">
                                    <div class="input-group-append">
                                    <button type="submit" name="search" class="btn btn-outline-secondary">Search</button>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="product-name" class="col-form-label">Book Name:</label>
                                    <input type="text" class="form-control" id="bname" name="bname" value="<?php if(isset($_POST['search'])) echo $title; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="product-name" class="col-form-label">Author:</label>
                                    <input type="text" class="form-control" id="author" name="author" value="<?php if(isset($_POST['search'])) echo $author; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="product-name" class="col-form-label">Genre:</label>
                                    <input type="text" class="form-control" id="category" name="category" value="<?php if(isset($_POST['search'])) echo $category; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="product-name" class="col-form-label">Publisher:</label>
                                    <input type="text" class="form-control" id="publisher" name="publisher" value="<?php if(isset($_POST['search'])) echo $publisher; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="product-name" class="col-form-label">Published Date:</label>
                                    <input type="text" class="form-control" id="published" name="published" value="<?php if(isset($_POST['search'])) echo $published; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="product-name" class="col-form-label">Page Count:</label>
                                    <input type="text" class="form-control" id="pagec" name="pagec" value="<?php if(isset($_POST['search'])) echo $pages; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="product-name" class="col-form-label">Description:</label>
                                    <textarea class="form-control" rows="10" maxlength="1000" id="description" name="description"><?php if(isset($_POST['search'])) echo $description; ?></textarea>
                                </div>
                            </form>
                                <div class="d-flex flex-column-reverse">
                                    <div class="align-self-end">
                                        <button onclick="submit()" name="create" style="vertical-align:middle; margin-top:12px; width: 30vh;" class="btn btn-Primary">Add Book</button>
                                        
                                    </div>
                                </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <!--SPACER-->
                    </div>
                </div>
            </div>     
        </div>
    </div>
</div>   
</body>
<script>
function submit(){
      var isbn = document.getElementById("isbn").value;
      var bname = document.getElementById("bname").value;
      var author =document.getElementById("author").value;
      var category = document.getElementById("category").value;
      var publisher = document.getElementById("publisher").value;
      var published = document.getElementById("published").value;
      var pages =document.getElementById("pagec").value;
      var description =document.getElementById("description").value;
      var pathh = "addbook.php?isbn="+isbn+" & bname="+bname+" & author="+author+" & category="+category+" & publisher="+publisher+" & published="+published+" & pagec="+pages+" & description="+description+" ";
      window.location.href = pathh;
    }
</script>
<?php
	session_start();
    require('./filecall.php'); 
	require "sqlconnection.php";
 
    if (!isset($_COOKIE['UserCookie'])){
		header('Location: index.php');
		exit;
	}
 
?>

<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
	<?php
		if(isset($_GET['bookID'])){
			include 'sqlconnection.php';
			$bookID = mysqli_real_escape_string($sqlcon, $_GET['bookID']);
			$sqlstring="select * FROM bookdb1 WHERE bookID='$bookID'";
			$resultset=mysqli_query($sqlcon, $sqlstring);
			while ($rowdata=mysqli_fetch_array($resultset)) 
			{	
				$bookID = $rowdata[0];
				$bookname = $rowdata[1];
				$author = $rowdata[2];
				$category = $rowdata[3];
				$isbn = $rowdata[4];
				$publisher = $rowdata[6];
				$published = $rowdata[7];
				$pages = $rowdata[8];
				$description = $rowdata[9];
			}
		}
		else{
			$bookID = "Enter book";
			$bookname = "Enter book";
			$author = "Enter book";
			$category = "Enter book";
			$isbn = "Enter book";
			$publisher = "Enter book";
			$published = "Enter book";
			$pages = "Enter book";
			$description = "Enter book";
		}
		function testfunc(){
			if(isset($_GET['back2view'])){
				echo ("<script LANGUAGE='JavaScript'>
			    window.location.href='viewbook.php';
			    </script>");
			}
		}
	?>
	</script>
</head>

<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigation.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">Book Details</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, <?php echo $_COOKIE['UserCookie']; ?>!</p>
            </div>
			
			<div class="col-12" id="midMain">
			<form name="" method='GET' target="viewbook.php">
			
			<div class="col-md-12 col-sm-12">
                    <div style="background-color:#f2f2f2;">
                        <div style="height:5vh; width:100%; background-color: #373b3e; color:fff;">
                            <p style="font-size:3.5vh; padding-left:650px;">Book Details</p>
                        </div>
				<center><table width="70%">	
				<tr>
					<td><br><b>Book ID: </td>
					<td><br><?php echo $bookID  ?></td>
					<td><br><b>ISBN: </td>
					<td><br><?php echo $isbn ?></td>
				<tr>
					<td><b>Book Name: </td>
					<td><?php echo $bookname ?></td>
					<td><b>Publisher: </td>
					<td><?php echo $publisher ?></td>
				<tr>
					<td><b>Author: </td>
					<td><?php echo $author ?></td>
					<td><b>Published date: </td>
					<td><?php echo $published ?></td>
				<tr>
					<td><b>Category: </td>
					<td><?php echo $category ?></td>
					<td><b>Pages: </td>
					<td><?php echo $pages ?></td>
				<tr>
					<td colspan="1"><b>Description/Excerpt: </td>
					<td colspan="3"><br><br><?php echo $description?></td>
				<tr>
					<td class="" colspan="4"><br><center><a href='viewbook.php'><input type='submit' name='back2view' value='Back'></a></center><br></td>
					
				</table><br><br>
				
					</div>
			</div>
			</div>
			</div>
			
			</div>
			</div>
			</div>
			</div>
			</form>	
			</div>
			
	</div>

</div>
</div>

<?php
	echo testfunc();
?>
</body>
</html>
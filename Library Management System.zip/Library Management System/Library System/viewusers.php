<?php
	session_start();
    require('./filecall.php'); 
	require "sqlconnection.php";
	
    if (!isset($_COOKIE['UserCookie'])){
		header('Location: index.php');
		exit;
	}
	if ($_COOKIE['UserType']=="Regular"){
		header('Location: regularform.php');
		exit;
	}
?>


<?php 
    function generaterecord(){
        include 'sqlconnection.php';
        $sqlstring="SELECT `userID`, `Username`, `Name`, `Type` FROM `userbase` WHERE Type='Regular' ORDER BY userID DESC";
        echo "<form name='update' method='GET'>";
        $resultset=mysqli_query($sqlcon, $sqlstring);


        while($rowdata = mysqli_fetch_array($resultset))  
            {  
                echo "<tr>"; 
                    echo "<td>$rowdata[0]</td>";
					          echo "<td>$rowdata[1]</td>";
                    echo "<td>$rowdata[2]</td>";
                    echo "<td>$rowdata[3]</td>";
                    echo '<td><button style="font-size: 0.8em; width: 8vh;" type="button" class="openupModal btn btn-warning" data-toggle="modal" data-target="#updateModal">Update</button>&nbsp';
                    echo '<button style="font-size: 0.8em; width: 8vh;" type="button" class="opendelModal btn btn-Danger" data-toggle="modal" data-target="#deleteModal">Delete</button></td>';
				    echo "</tr>";
            }  
        mysqli_close($sqlcon);
        
    }	
?>



<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
    <title>Malabon City Library</title>
    <link rel="stylesheet" href="stylesheet3.css">
    <link rel="icon" type="image/x-icon" href="Background/malabonicon.png">
	<script>
	function printtest(){
		var divToPrint=document.getElementById("ShowTable");
		newWin= window.open("");
		newWin.document.write(divToPrint.outerHTML);
		newWin.print();
		newWin.close();
	}
	</script>
</head>

<body class="container-fluid">
<div class="row">
    <!--NAVBAR -->
    <?php include('navigation.php');?>
    <!--SPACER FOR THE LEFT NAVIGATION-->
    <div class="col-md-2">  
    </div>
    <!--BODY-->
    <div class="col-12 col-md-10" id="mainpanel">
        <div class="row">
            <div class="col-12 pt-3" id="topMain"><p id="titleTop">View / Users</p></div>
            <div class="col-12 d-flex flex-column" id="botmain">
                <p class="mt-1" id="bottomLabel" style = "color: rgb(219, 219, 219);
                font-size: 15px;
                margin-left: 5px;">Welcome, <?php echo $_COOKIE['UserCookie']; ?>!</p>
            </div>

            <div class="col-12 p-2" id="midMain">
                
                <div class="col-12 overflow-auto" style="height: 79vh; background-color: #f2f2f2;">
                    <div class="p-3">  
                        <table id="ShowTable" class="table table-striped table-bordered">  
                                <thead class="table-dark" style="position: sticky; top: 0; z-index: 1;">
                                <tr>  
                                        <td id="row1vu">UserID</td>  
                                        <td id="row2vu">Username</td>  
                                        <td id="row3vu">Name</td>   
                                        <td id="row5vu">Type</td>  
                                        <td id="row6vu">Update</td>  

                                </tr>  
                            </thead> 
                            <tbody> 
                                <?php
                                    echo generaterecord();
                                ?>
                            </tbody> 
                        </table>  
                    </div>
                </div> 
                
                <div class="d-flex flex-column-reverse">
                    <div class="align-self-end">
                         <button class="btn btn-primary" style="vertical-align:middle; margin-top:10px; margin-right:30px; width: 30vh;" onclick="printtest()">Print Table Page</button><button style="vertical-align:middle; margin-top:10px; margin-right:30px; width: 30vh;" type="button" class="btn btn-Primary" data-toggle="modal" data-target="#addModal">Add Account</button>
                    </div>
                </div>
                
            </div>
                 
        </div>
    </div>
</div>   
</body>

<!-- Modal Delete-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="productname"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="border:0; background: 000;">
        <span aria-hidden="true"><i class="fa-sharp fa-solid fa-xmark"></i></span>
        </button>
      </div>
      <div class="modal-body">
            Are you sure you want to delete this Account?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a id="delete"><button class="btn btn-danger">Delete Account</button></a>
      </div>
    </div>
  </div>
</div>

<!-- Modal Update-->
<div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="productname">Update Book</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="border:0; background: 000;">
          <span aria-hidden="true"><i class="fa-sharp fa-solid fa-xmark"></i></span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-group">
            <label for="book-id" class="col-form-label">User ID:</label>
            <input type="text" class="form-control" id="user-id" name="user-id" readonly required>
          </div>
          <div class="form-group">
            <label for="book-name" class="col-form-label">Username:</label>
            <input type="text" class="form-control" id="user-name" name="user-name" required>
          </div>
          <div class="form-group">
            <label for="author-name" class="col-form-label">Password:</label>
            <input type="text" class="form-control" id="user-pass" name="user-pass" required>
          </div>
          <div class="form-group">
            <label for="genre-name" class="col-form-label">Name:</label>
            <input type="text" class="form-control" id="name" name="name" required>
          </div>
      </div>
      <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button onclick="submit()" class="btn btn-warning">Update Account</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal AddProd-->


<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="productname">Add Account</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="border:0; background: 000;">
          <span aria-hidden="true"><i class="fa-sharp fa-solid fa-xmark"></i></span>
        </button>
      </div>
      <div class="modal-body">
        
          <div class="form-group">
            <label for="product-id" class="col-form-label">User ID:</label>
            <input type="text" class="form-control" id="user-id" name="user-id" placeholder="Automatically Generated" readonly>
          </div>
          <div class="form-group">
            <label for="product-name" class="col-form-label">Username:</label>
            <input type="text" class="form-control" id="un-add" name="user-name" required>
          </div>
          <div class="form-group">
            <label for="product-name" class="col-form-label">Password:</label>
            <input type="text" class="form-control" id="user-pass-add" name="user-pass" required>
          </div>
          <div class="form-group">
            <label for="product-name" class="col-form-label">Name:</label>
            <input type="text" class="form-control" id="name-add" name="name" required>
          </div>
          <div class="form-group">
            <label for="product-name" class="col-form-label">Type:</label>
            <select id="type-add" class="form-control">
            <option selected>Regular</option>
            <option disabled>Admin</option>
            </select>
          </div>  
      </div>
      <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button onclick="submit1()" class="btn btn-primary">Add Account</button>    
      </div>
    </div>
  </div>
</div>



<!-- for modal -->
<script type="text/javascript">
    $("#ShowTable").on('click','.opendelModal',function () {
        var currentRow=$(this).closest("tr");
        var id = currentRow.find("td:eq(0)").text();
        var name = currentRow.find("td:eq(1)").text();
        document.getElementById("productname").innerHTML = name;
        document.getElementById("delete").href = "deleteuser.php?id=".concat(id);
    });
    $("#ShowTable").on('click','.openupModal',function () {
        var currentRow=$(this).closest("tr");
        var id = currentRow.find("td:eq(0)").text();
        var username = currentRow.find("td:eq(1)").text();
        var pass = currentRow.find("td:eq(2)").text();
        var name = currentRow.find("td:eq(3)").text();
        document.getElementById("user-id").value = id;
        document.getElementById("user-name").value = username;
        document.getElementById("user-pass").value = pass;
        document.getElementById("name").value = name;
    });

    function submit(){
      var id1 = document.getElementById("user-id").value;
      var username1 = document.getElementById("user-name").value;
      var pass1 = document.getElementById("user-pass").value;
      var name1 =document.getElementById("name").value;
      var pathh = "updateuser.php?id="+id1+"&un="+username1+"&pass="+pass1+"&name="+name1+" ";
      window.location.href = pathh;
    }

    function submit1(){
      var username12=document.getElementById("un-add").value;
      var pass12=document.getElementById("user-pass-add").value;
      var name12=document.getElementById("name-add").value;
      var type12=document.getElementById("type-add").value;
      var pathh="adduser.php?un="+username12+"&pass="+pass12+"&name="+name12+"&type="+type12+" ";
      window.location.href = pathh;
    }

</script>
